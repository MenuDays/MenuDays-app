import React, { useCallback, useState } from "react";
import { View, StyleSheet, FlatList, Text, ActivityIndicator, TouchableOpacity, Image, RefreshControl } from "react-native";
import { useFocusEffect } from "@react-navigation/native";
import { Ionicons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import ScreenHeader from "../components/restaurant/ScreenHeader";
import RestaurantBottomNav from "../components/restaurant/RestaurantBottomNav";
import GalleryService, { GalleryImage } from "../../services/gallery.service";
import { AppAlert } from "../components/common/AppAlert";

export default function GalleryScreen() {
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [uploading, setUploading] = useState(false);

  async function loadGallery() {
    try {
      const data = await GalleryService.getAll();
      setImages(data);
    } catch (e: any) {
      AppAlert.alert("Error", e.message || "No se pudo cargar la galería.");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  useFocusEffect(
    useCallback(() => {
      loadGallery();
    }, [])
  );

  function handleRefresh() {
    setRefreshing(true);
    loadGallery();
  }

  async function handleAddPhoto() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      AppAlert.alert("Permiso necesario", "Necesitamos acceso a tus fotos.");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"],
      quality: 0.8,
      allowsEditing: true,
    });
    if (result.canceled) return;

    setUploading(true);
    try {
      const uploaded = await GalleryService.upload(result.assets[0].uri);
      setImages((prev) => [uploaded, ...prev]);
    } catch (e: any) {
      AppAlert.alert("Error", e.message || "No se pudo subir la foto.");
    } finally {
      setUploading(false);
    }
  }

  function handleOpenImageOptions(image: GalleryImage) {
    const buttons = [
      ...(image.es_portada
        ? []
        : [
            {
              text: "Usar como portada",
              onPress: () => handleSetCover(image.id),
            },
          ]),
      {
        text: "Eliminar",
        style: "destructive" as const,
        onPress: () => handleDelete(image.id),
      },
      { text: "Cancelar", style: "cancel" as const },
    ];
    AppAlert.alert("Foto de la galería", undefined, buttons);
  }

  async function handleSetCover(id: string) {
    try {
      await GalleryService.setCover(id);
      setImages((prev) => prev.map((img) => ({ ...img, es_portada: img.id === id })));
    } catch (e: any) {
      AppAlert.alert("Error", e.message || "No se pudo actualizar la portada.");
    }
  }

  function handleDelete(id: string) {
    AppAlert.alert("Eliminar foto", "¿Seguro que querés eliminar esta foto?", [
      { text: "Cancelar", style: "cancel" },
      {
        text: "Eliminar",
        style: "destructive",
        onPress: async () => {
          try {
            await GalleryService.remove(id);
            setImages((prev) => prev.filter((img) => img.id !== id));
          } catch (e: any) {
            AppAlert.alert("Error", e.message || "No se pudo eliminar la foto.");
          }
        },
      },
    ]);
  }

  return (
    <View style={styles.container}>
      <ScreenHeader
        title="Galería"
        rightIcon={uploading ? undefined : "add"}
        onRightPress={handleAddPhoto}
      />

      {uploading ? (
        <View style={styles.uploadingBar}>
          <ActivityIndicator size="small" color="#FB8C00" />
          <Text style={styles.uploadingText}>Subiendo foto...</Text>
        </View>
      ) : null}

      {loading ? (
        <ActivityIndicator size="large" color="#FB8C00" style={styles.loader} />
      ) : (
        <FlatList
          data={images}
          keyExtractor={(item) => item.id}
          numColumns={3}
          columnWrapperStyle={styles.row}
          contentContainerStyle={styles.grid}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor="#FB8C00" />
          }
          ListEmptyComponent={
            <View style={styles.emptyWrap}>
              <Ionicons name="images-outline" size={36} color="#D9D9D9" />
              <Text style={styles.emptyText}>
                Todavía no subiste fotos. Tocá + para agregar la primera.
              </Text>
            </View>
          }
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.cell}
              activeOpacity={0.85}
              onPress={() => handleOpenImageOptions(item)}
            >
              <Image source={{ uri: item.url }} style={styles.cellImage} />
              {item.es_portada ? (
                <View style={styles.coverBadge}>
                  <Ionicons name="star" size={12} color="#FFFFFF" />
                </View>
              ) : null}
            </TouchableOpacity>
          )}
        />
      )}

      <RestaurantBottomNav />
    </View>
  );
}

const GAP = 4;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FAFAFA",
  },
  loader: {
    marginTop: 40,
  },
  uploadingBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 10,
  },
  uploadingText: {
    fontSize: 13,
    color: "#9E9E9E",
    fontWeight: "600",
  },
  grid: {
    padding: GAP,
    paddingBottom: 120,
  },
  row: {
    gap: GAP,
  },
  cell: {
    flex: 1 / 3,
    aspectRatio: 1,
    margin: GAP / 2,
    borderRadius: 10,
    overflow: "hidden",
    backgroundColor: "#F0F0F0",
  },
  cellImage: {
    width: "100%",
    height: "100%",
  },
  coverBadge: {
    position: "absolute",
    top: 6,
    left: 6,
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: "#FB8C00",
    alignItems: "center",
    justifyContent: "center",
  },
  emptyWrap: {
    alignItems: "center",
    marginTop: 60,
    paddingHorizontal: 40,
    gap: 10,
  },
  emptyText: {
    textAlign: "center",
    color: "#9E9E9E",
    fontSize: 13,
  },
});